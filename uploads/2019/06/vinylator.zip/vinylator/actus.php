<?php
/* Template Name: actus */ ?>

<?php get_header(); ?>


<section id="actus" class="container-fluid">
    <div class="container">
        <h2>LES ACTUS DU VINYLES<span class="small_underline"></h2>
        <div class="row somewhere alasuite">
        </div>
    </div>
</section>

<?php get_footer(); ?>