<?php
/* Template Name: archive */ ?>

<?php get_header(); ?>


<section id="category" class="container-fluid">
    <div class="container">
        <h2>LISTE DES VINYLES<span class="small_underline"></h2>
        <div class="row somewhere-album alasuite-album">
        </div>
    </div>
</section>

<?php get_footer(); ?>