<?php get_header(); ?>

<section id="list-post" class="container">
<?php  

$queried_object = get_queried_object(); 
$taxonomy = $queried_object->taxonomy;
$term_id = $queried_object->name;  

echo('<h2 class="text-center">'.strtoupper ($GLOBALS['wp_embed']->post_ID = $term_id).'<h2>');

?>
<hr>
<div class="row">

<?php

if (have_posts()) {
    while (have_posts()) {
        the_post();
        ?>

        
    <article class="actu col-4">
        
        
            <figure class="img-intro mt-5 mb-5">
            <div class="link_img">
                <a href="http://localhost:8080/album/<?php echo strtolower(str_replace(' ', '-', get_the_title('', '', false))) ?>/">
                <?php 
                $image_id = get_post_custom($post->ID, '_cover', true)['_data_image'][0];
                $image = wp_get_attachment_image($image_id, $size = 'normal');
                
                echo $image;
                ?><div class="hover-image"></div><p class="decouvrir text-center">DECOUVRIR</p></a>
                 </div>
            </figure>
       
            <a href="http://localhost:8080/album/<?php echo strtolower(str_replace(' ', '-', get_the_title('', '', false))) ?>/"><h3 class="text-center"><?php the_title(); ?></h3></a>
            <a href="http://localhost:8080/album/<?php echo strtolower(str_replace(' ', '-', get_the_title('', '', false))) ?>/"><p class="text-center infos mb-4"><?php echo get_post_custom($post->ID, '_album_info', true)['_label'][0];?> | <?php echo get_post_custom($post->ID, '_album_info', true)['_date-sortie'][0];?></p>
            </a>
            <a href="http://localhost:8080/album/<?php echo strtolower(str_replace(' ', '-', get_the_title('', '', false))) ?>/"><?php the_excerpt(); ?></a>
    </article>
    <?php
    }
}
?>

</div>

</section>

<?php get_footer(); ?>
